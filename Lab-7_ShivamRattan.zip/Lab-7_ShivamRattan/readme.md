Ver 1.0
This is a simple time duration calculator given to me as an assignment for my fullstack dev course.
The problem statement can be found at https://www.youtube.com/watch?v=PJF_5VGUa_Q&feature=youtu.be
A since thanks to my lecturer Mike for sharing this problem
